<div class="stm_lms_announcement">
	<?php STM_LMS_Templates::show_lms_template('manage_course/forms/editor', array('field_key' => 'announcement')); ?>
</div>