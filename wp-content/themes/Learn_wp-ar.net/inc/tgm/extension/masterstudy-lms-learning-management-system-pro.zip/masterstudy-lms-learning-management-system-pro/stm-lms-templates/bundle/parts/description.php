<div class="stm_lms_course__image">
    <?php echo stm_lms_lazyload_image( stm_get_VC_img( get_post_thumbnail_id(get_the_ID()), '870-440' ) ); ?>
</div>

<div class="stm_lms_course__content">
	<?php the_content(); ?>
</div>